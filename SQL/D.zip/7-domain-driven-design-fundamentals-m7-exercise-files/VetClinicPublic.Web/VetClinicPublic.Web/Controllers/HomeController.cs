﻿using System;
using System.Linq;
using System.Web.Mvc;

namespace VetClinicPublic.Web.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

    }
}