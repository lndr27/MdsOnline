﻿using System;
using System.Linq;

namespace FrontDesk.SharedKernel.Interfaces
{
    public interface IDomainEvent
    {
        DateTime DateTimeEventOccurred { get; }
    }
}
