ddd-vet-sample
==============

This is a work in progress / sandbox.  Please don't assume anything in this repository is working code or a good practice.

A sample meant to demonstrate domain driven design using a veterinary hospital management system.

In the last module we introduce passing events between two separate applications.  You'll need a full instance of sql server to run this on your machine (without modification to the source), and you'll need to configure SQL Service Broker using the SetupSQLServiceBroker.sql script in the root of this project.


