using System;

namespace FrontDesk.Web.Models
{
    public class DoctorViewModel
    {
        public int DoctorId { get; set; }
        public string Name { get; set; }
    }
}